setwd("C:/Users/xxx/Desktop/[R script] Tree age calculator")
growth<-read.csv("growth.csv", sep=";",dec=",",header=TRUE)
str(growth)
growth$species<-as.character(as.factor(growth$species))

require(shiny)
library(shiny)
shinyApp(
    ui = fluidPage(
        headerPanel(h1("Tree age estimation",align="center")),
        mainPanel(
            fluidRow(
                column(10,offset = 10, style='padding:0px;margin:0px',
                       mainPanel(selectInput("CHOSENspecies",
                                             "Tree species/genus:",
                                             choices = c("", growth$species),),
                                 
                                 numericInput("circ", "Circumference at breast high (cm)","",
                                              width = 500,min=0),
                                 
                                 
                                 textOutput("result"))),
                column(2,align="left",offset = 10,style = "position:absolute;right:150px;z-index:1000;" ,
                       img(src="Old_tree.PNG",width=500,length=500))
            )
        ),
        
    ),
    
    
    
    server = function(input, output) {
        
        output$result <- renderText({
            paste("Your tree is likely to be around",ifelse(input$CHOSENspecies=="","?",
                                                          ifelse(is.na(round(
                                                              (input$circ/pi)*(growth[growth$species == input$CHOSENspecies,]
                                                                               $growth_factor_cm))),"?",ifelse(round(
                                                                                   (input$circ/pi)*(growth[growth$species == input$CHOSENspecies,]
                                                                                                    $growth_factor_cm))=="","?",round(
                                                                                                        (input$circ/pi)*(growth[growth$species == input$CHOSENspecies,]
                                                                                                                         $growth_factor_cm))))),"years old.",
                  
                  paste(na.omit(ifelse(input$circ<0,"This sounds quite unlikely, though.
                           Please put positive values for the circumferences.",ifelse(round(
                               (input$circ/pi)*(growth[growth$species == input$CHOSENspecies,]
                                                $growth_factor_cm))>500,"Now that is one OLD tree!",""))))
            )
            
        })
    }
)
